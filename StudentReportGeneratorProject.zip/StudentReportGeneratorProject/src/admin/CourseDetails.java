package admin;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CourseDetails
 */
@WebServlet("/CourseDetails")
public class CourseDetails extends HttpServlet {


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String sid=request.getParameter("sid");
		String ccode=request.getParameter("ccode");
		String cname=request.getParameter("cname");
		String ccd=request.getParameter("ccd");
		String grade=request.getParameter("grade");
		String marks=request.getParameter("marks");
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("Driver is set");
			Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","HR","hr");
			System.out.println("Connection Established");
			PreparedStatement ps=conn.prepareStatement("insert into studentscoursedetails values(?,?,?,?,?,?)");
			ps.setString(1,sid);
			ps.setString(2, ccode);
			ps.setString(3, cname);
			ps.setString(4, ccd);
			ps.setString(5, grade);
			ps.setString(6, marks);
			
			int i=ps.executeUpdate();
			if(i>0)
			{
				out.println("Data Saved into Database");
				RequestDispatcher rd=request.getRequestDispatcher("adminLogin.jsp");
				rd.include(request, response);
			}
			else 
			{
				out.println("Data is not registered");
				RequestDispatcher rd=request.getRequestDispatcher("adminLogin.jsp");
				rd.include(request, response);
			}
			
		}
		catch(Exception e)
		{
			
		}
		
	}

	



	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
