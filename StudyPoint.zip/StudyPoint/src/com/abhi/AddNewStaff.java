package com.abhi;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/AddNewStaff")
public class AddNewStaff extends HttpServlet implements DBIntializer{
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		String sid=request.getParameter("sid");
		String sname=request.getParameter("sname");
		String spass=request.getParameter("spass");
		
		try
		{
			Class.forName(DRIVER);
			System.out.println("Driver is set");
			Connection conn=DriverManager.getConnection(URL, USERNAME, PASSWORD);
			System.out.println("Connection Established");
			System.out.println("Inserting data into staff table...");
			PreparedStatement stmt=conn.prepareStatement("insert into staff values(?,?,?)"); 
			stmt.setString(1, sid);
			stmt.setString(2, sname);
			stmt.setString(3, spass);
			
			int i=stmt.executeUpdate();
			System.out.println(i+"Record inserted");
			if(i>=1)
			{
				out.println("<h2>Record Inserted</h2>");
				RequestDispatcher rd=request.getRequestDispatcher("Admin.jsp");
				rd.include(request, response);
			}
			else
			{
				out.println("<h2>Record Not Inserted</h2>");
				RequestDispatcher rd=request.getRequestDispatcher("addnewstaff.jsp");
				rd.include(request, response);
			}

			conn.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
