package com.abhi;
import Bean.StaffLoginDao;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/StaffLogin")
public class StaffLogin extends HttpServlet implements DBIntializer {


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		String sid=request.getParameter("sid");
		String spass=request.getParameter("spass");
		
		 if(StaffLoginDao.validate(sid,spass))
         {  
              RequestDispatcher rd=request.getRequestDispatcher("staff.jsp");  
              rd.forward(request,response);  
         }  
         else
         {  
              out.print("Sorry username or password error");  
              RequestDispatcher rd=request.getRequestDispatcher("staffLogin.jsp");  
              rd.include(request,response);  
         }  
         out.close();  

		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
