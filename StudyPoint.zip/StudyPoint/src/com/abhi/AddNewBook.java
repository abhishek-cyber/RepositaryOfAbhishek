package com.abhi;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Bean.AddNewBookDao;


@WebServlet("/AddNewBook")
public class AddNewBook extends HttpServlet{

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		String id=request.getParameter("bid");
		String name=request.getParameter("bname");
		String author=request.getParameter("author");
		
		System.out.println("Getting data from form"+id+name+author);
		
		if(AddNewBookDao.validate(id,name,author))
        {  
			System.out.println("Using the validate method");
             RequestDispatcher rd=request.getRequestDispatcher("staff.jsp");  
             rd.forward(request,response);  
        }  
        else
        {  
             out.print("Data Incorrect");  
             RequestDispatcher rd=request.getRequestDispatcher("header.html");  
             rd.include(request,response);  
        }  
        out.close(); 
		
			
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
