package com.abhi;

public interface DBIntializer {
	String DRIVER="oracle.jdbc.driver.OracleDriver";
	String URL="jdbc:oracle:thin:@localhost:1521:orcl";
	String USERNAME="HR";
	String PASSWORD="hr";

}
