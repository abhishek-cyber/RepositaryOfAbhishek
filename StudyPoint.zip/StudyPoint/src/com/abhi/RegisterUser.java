package com.abhi;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/RegisterUser")
public class RegisterUser extends HttpServlet implements DBIntializer{

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		
		
		String userid=request.getParameter("username");
		String name=request.getParameter("name");
		String pass=request.getParameter("password");
		String cpass=request.getParameter("repassword");
		String mobile=request.getParameter("phone");
		String address=request.getParameter("add");
		
		if(pass.equals(cpass))
		{
			try
			{
				Class.forName(DRIVER);
				System.out.println("Driver is set..");
				Connection conn=DriverManager.getConnection(URL,USERNAME,PASSWORD);
				System.out.println("Connection Established...");
				System.out.println("Inerting data into newmember table...");
				PreparedStatement stmt=conn.prepareStatement("insert into newmember values(?,?,?,?,?)");
				stmt.setString(1, userid);
				stmt.setString(2, name);
				stmt.setString(3, pass);
				stmt.setString(4, mobile);
				stmt.setString(5, address);
				int i=stmt.executeUpdate();
				System.out.println(i+" "+"Record inserted");
				if(i>=1)
				{
					out.println("<h2>Record Inserted</h2>");
					RequestDispatcher rd=request.getRequestDispatcher("userLogin.jsp");
					rd.include(request, response);
				}
				else
				{
					out.println("<h2>Record Not Inserted</h2>");
					RequestDispatcher rd=request.getRequestDispatcher("registerUser.jsp");
					rd.include(request, response);
				}
				conn.close();
			}
		
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		}
		
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
