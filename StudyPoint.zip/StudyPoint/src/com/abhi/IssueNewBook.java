package com.abhi;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Bean.AddNewBookDao;
import Bean.IssueNewBookDao;


@WebServlet("/IssueNewBook")
public class IssueNewBook extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
	
		String id=request.getParameter("bid");
		
		 
		if(IssueNewBookDao.validate(id))
        {  
			System.out.println("Using the validate method");
             RequestDispatcher rd=request.getRequestDispatcher("member.jsp");  
             rd.forward(request,response);  
             System.out.println("Book Issued...");
        }  
        else
        {  
             out.print("<h2>Data Incorrect</h2>");  
             RequestDispatcher rd=request.getRequestDispatcher("header.html");  
             rd.include(request,response);  
        }  
        out.close();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
