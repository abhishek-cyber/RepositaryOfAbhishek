package com.abhi;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Bean.UserLoginDao;


@WebServlet("/UserLogin")
public class UserLogin extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		String uid=request.getParameter("uid");
		String upass=request.getParameter("upass");
		
		if(UserLoginDao.validate(uid,upass))
        {  
             RequestDispatcher rd=request.getRequestDispatcher("member.jsp");  
             rd.forward(request,response);  
        }  
        else
        {  
             out.print("Sorry username or password error");  
             RequestDispatcher rd=request.getRequestDispatcher("userLogin.jsp");  
             rd.include(request,response);  
        }  
        out.close(); 
	}
	


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
