package Bean;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.abhi.DBIntializer;

public class IssueNewBookDao implements DBIntializer{

	public static boolean validate(String id)
    {  
         boolean status=false;
         try
         {  
              Class.forName(DRIVER);  
              Connection con=DriverManager.getConnection(URL,USERNAME,PASSWORD);  
             java.util.Date date=new java.util.Date();  
             java.sql.Date sqlDate = new java.sql.Date(date.getTime());

              String sql="update book set issued_date=? where id=?";
             PreparedStatement ps=con.prepareStatement(sql);
             ps.setDate(1, sqlDate);
             ps.setString(2, id);
             
            ps.executeUpdate();
              
              System.out.println("book issuing.");
              		  
             
         }
         catch(Exception e)
         {
              System.out.println(e);
         }  
         return status;  
    }
}
