package Bean;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.abhi.DBIntializer;

public class UserLoginDao implements DBIntializer {

	 public static boolean validate(String uid,String upass)
     {  
          boolean status=false;
          try
          {  
               Class.forName(DRIVER);  
               Connection con=DriverManager.getConnection(URL,USERNAME,PASSWORD);  
      
               PreparedStatement ps=con.prepareStatement(  
               "select * from newmember where user_id=? and password=?");  
               ps.setString(1,uid);  
               ps.setString(2,upass);
               ResultSet rs=ps.executeQuery();  
               status=rs.next();  
          }
          catch(Exception e)
          {
               System.out.println(e);
          }  
          return status;  
     }
}
