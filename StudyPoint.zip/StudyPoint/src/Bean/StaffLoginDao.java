package Bean;
import com.abhi.DBIntializer;
import java.sql.*;  
public class StaffLoginDao implements DBIntializer
{  
     public static boolean validate(String sid,String spass)
     {  
          boolean status=false;
          try
          {  
               Class.forName(DRIVER);  
               Connection con=DriverManager.getConnection(URL,USERNAME,PASSWORD);  
      
               PreparedStatement ps=con.prepareStatement(  
               "select * from staff where id=? and password=?");  
               ps.setString(1,sid);  
               ps.setString(2,spass);
               ResultSet rs=ps.executeQuery();  
               status=rs.next();  
          }
          catch(Exception e)
          {
               System.out.println(e);
          }  
          return status;  
     }  
}

