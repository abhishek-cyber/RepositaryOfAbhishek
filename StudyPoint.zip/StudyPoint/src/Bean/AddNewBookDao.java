package Bean;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.abhi.DBIntializer;

public class AddNewBookDao implements DBIntializer{
	
	public static boolean validate(String bid,String bname,String author)
    {  
         boolean status=false;
         try
         {  
              Class.forName(DRIVER);  
              Connection con=DriverManager.getConnection(URL,USERNAME,PASSWORD);  
     
              PreparedStatement ps=con.prepareStatement("insert into book(ID,NAME,AUTHOR) values(?,?,?)");  
              ps.setString(1,bid);  
              ps.setString(2,bname);
              ps.setString(3, author);
              ResultSet rs=ps.executeQuery();  
              status=rs.next(); 
              System.out.println("Book record inserted");
         }
         catch(Exception e)
         {
              System.out.println(e);
         }  
         return status;  
    }

}
